 public class B extends A{
		 public void f1(){ //this is allowed
		 System.out.println("in B f1");
		 }
		public void f3(){
			 System.out.println("in f3");
		}
		 public void f2(){
		 super.f2();
		 }
		 public void f4(){
				System.out.println("class B-f4()");
			}
		 public static void disp()
		 {
			 System.err.println("B-disp func");
		 }
		}
		

