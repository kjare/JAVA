
public class A {

	 
		 public void f2(){
		 }
		
		public void f4(){
			System.out.println("class A-f4()");
		}
	
}
