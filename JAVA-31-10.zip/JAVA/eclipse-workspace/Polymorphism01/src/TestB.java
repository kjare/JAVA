public class TestB{
 public static void main(String[] args){
 A ob;
 ob=new B();
 //ob.f1();
 ob.f4();
 //ob.f3(); // error to call it use ((B)ob).f3()
 ((B) ob).disp();
 }
}
