package person2;

public class Person {

	public static void disp()
	{
		System.out.println("in different pkg");

	}
	
	public static void main(String[] args) {
//		Person p = new Person();
//		p.disp();
		disp();
	}
	
}
