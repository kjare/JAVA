
public class TestPerson {

	public static void main(String[] args) {
		Person p = new Person (12,"kishori", "333");
		//p.displayPerson();
		System.out.println(p);
		p.setid(555);
		//System.out.println(p);
		//p.getid();
		System.out.println(p.getid());
		System.out.println(p);
//		Person p1 = new Person (13,"radha", "444");
//		//p1.displayPerson();
//		System.out.println(p1);

	}

}
