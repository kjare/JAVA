import person2.*;
public class Person {
	private int pid;
	private String pname;
	private String pmobile;
	// default constructor
	public Person()
	{
		pid = 0;
		pname = null;
		pmobile = null;
	}
	// parameterized constructor
	public Person(int id, String name, String mobile)
	{
		this.pid = id;
		this.pname = name;
		this.pmobile = mobile;
	}
	// setter functions
	public void setid(int id)
	{
		this.pid = id;
	}
	public void setname(String name)
	{
		this.pname = name;
	}
	public void setMobile(String mob)
	{
		this.pmobile = mob;
	}
	// getter functions
	public int getid()
	{
		return this.pid;
	}
	public String getName()
	{
		return pname;
	}
	public String getMobile()
	{
		return pmobile;
	}
	// member method 
//	public void displayPerson()
//	{
//		System.out.println("pid : "+this.pid);
//		System.out.println("pname : "+this.pname);
//		System.out.println("pmobile : "+this.pmobile);
//	}
	
	public String toString()
	{
		return "pid : "+this.pid+"\nName : "+this.pname+"\nMobile : "+this.pmobile;
	}
}
