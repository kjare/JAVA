
public class TestBook {

	public static void main(String[] args) {
//		Book b=new Book(2,"java","byKiran");
//   		System.out.println(b);
//   		
//		Book.Lesson l1=b.new Lesson();
//        l1.m1();
        OuterClass ob=new OuterClass();
        OuterClass.InnerClass ob1=new OuterClass.InnerClass();
        ob1.test();
	}

}
