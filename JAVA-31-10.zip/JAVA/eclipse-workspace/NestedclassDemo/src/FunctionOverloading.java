
public class FunctionOverloading {
	public static void add(Integer i,Integer j) {
		System.out.println("in Integer add");
	}
	public static void add(int i,int j) {
		System.out.println("in int add");
	}
	public static void add(float i,float j) {
		System.out.println("in float add");
	}
	public static void main(String[] args) {
		//add(128,1389);
		//add(new Integer(30,34));
		//final int i=23;
		//i=34;
		
		add(new Float(30),new Float(30));
		//c.method(new Integer(15));
		add(new Integer(30),new Integer(30));
	}

}
