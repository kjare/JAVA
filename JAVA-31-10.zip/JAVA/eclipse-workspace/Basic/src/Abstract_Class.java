
abstract public class Abstract_Class {
	public static void show()
	{
		
	}

}
