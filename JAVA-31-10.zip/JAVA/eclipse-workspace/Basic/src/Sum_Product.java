import java.util.*;
public class Sum_Product {
	public static void main(String[] args) {
		double a, b;
		double sum, pro;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a : ");
		a = sc.nextDouble();
		System.out.println("Enter b : ");
		b = sc.nextDouble();
		sum = a + b;
		pro = a * b;
		System.out.println("sum is : "+sum);
		System.out.println("product is : "+pro);
		sc.close();
	}
	
}
