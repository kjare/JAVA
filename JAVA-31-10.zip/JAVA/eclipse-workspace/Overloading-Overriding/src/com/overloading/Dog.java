package com.overloading;

public class Dog {

}
