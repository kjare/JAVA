
public class Service {

	public static void main(String[] args) {
	
		 // If a Parent type reference refers
        // to a Parent object, then Parent's
        // show is called
			Dog d=new Dog();
			d.bark();
		
			// If a Parent type reference refers
	        // to a Child object Child's bark()
	        // is called. This is called RUN TIME
	        // POLYMORPHISM.
			Dog d1=new Hound();
			d1.bark();
			
			
		}


	}


