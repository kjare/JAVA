
public class Dog {

	public void bark()
	{
		System.out.println("in parent class - bark()");
	}
	
}
