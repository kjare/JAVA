
public class Hound extends Dog{

	
	public void bark()
	{
		System.out.println("in child class - bark()");
	}

}
