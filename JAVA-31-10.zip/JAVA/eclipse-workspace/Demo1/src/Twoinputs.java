
import java.util.Scanner;
public class Twoinputs {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number 1 : ");
		int num1=sc.nextInt();
		
		System.out.println("enter number 2 : ");
		int num2 = sc.nextInt();
		
		int ans=NumberService.addition(num1,num2);
		System.out.println("addition : "+ans);
		
		ans = NumberService.add_digits(num2);
		System.out.println("Add_digits : "+ans);
		sc.close();
	}

}
