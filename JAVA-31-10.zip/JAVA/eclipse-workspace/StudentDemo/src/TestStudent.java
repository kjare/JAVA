
public class TestStudent {

	public static void main(String[] args) {
		
		Student s=new Student("kritika",54,67,34);
		System.out.println(s);
		Student s1=new Student();
		System.out.println(s1);

	}

}
