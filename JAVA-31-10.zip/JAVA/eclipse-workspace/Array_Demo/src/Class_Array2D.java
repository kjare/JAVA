
public class Class_Array2D {

	public static void main(String[] args) {
		
		int[][] arr=new int[3][3];
		int[][] arr1=new int[3][3];
		Array2DService.acceptData(arr);
		Array2DService.acceptData(arr1);
		System.out.println();
		Array2DService.displayData(arr);
		System.out.println();
		Array2DService.displayData(arr1);
		
		int[][] arr2=Array2DService.add(arr,arr1);
		System.out.println();
		System.out.println("Addition of two 2d Matrix : \n");
		Array2DService.displayData(arr2);
		
		
		
		int[][] arr3=Array2DService.transpose(arr);
		System.out.println();
		System.out.println("Transpose of 2d Matrix : \n");
		Array2DService.displayData(arr3);
		
		
		int Max=Array2DService.findMaxValue(arr);
		System.out.println("Maximum element is : "+Max);
		
		
		
		
		int Min=Array2DService.findMinValue(arr);
		System.out.println("Minimum element is : "+Min);
		
		
		
		int val=5;
		int freq=Array2DService.findFrequency(arr,val);
		System.out.println("Frequency of "+val+" is : "+freq);
	}

}
