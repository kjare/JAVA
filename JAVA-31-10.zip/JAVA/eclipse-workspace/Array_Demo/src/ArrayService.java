import java.util.*;
public class ArrayService {
	public static int findSum(int [] arr)
	{
		int s = 0;
		for(int val:arr)
		{
			s = s + val;
		}
		return s;
	}

	public static int[] findAllGreaterVal(int[] arr, int v) {
		int[] temp = new int[arr.length];
		int cnt = 0;
		for(int val : arr)
		{
			if(val>v)
			{
				temp[cnt] = val;
				cnt++;
			}
		}
		for(int i = cnt; i<temp.length;i++)
		{
			temp[cnt]=-1;
		}
		return temp;
	}

	public static void acceptData(int[] arr) {
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<arr.length; i++)
		{
			System.out.println("Enter number : "+(i+1));
			arr[i] = sc.nextInt();
		}
		
	}

	public static void displayData(int[] arr) {
		for(int i=0; i<arr.length; i++)
		{
			System.out.println((i+1)+ ":" + arr[i]);
		}
		
	}

	public static int searchValue(int[] arr, int val) {
		for(int i=0; i<arr.length; i++)
		{
			if(arr[i]==val) {
				return i;
			}
		}
		return -1;
	}

}
