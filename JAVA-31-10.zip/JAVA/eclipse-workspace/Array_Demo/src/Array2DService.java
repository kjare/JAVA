import java.util.Scanner;

public class Array2DService {

	public static void acceptData(int[][] arr) {
	
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[0].length;j++)
			{
				System.out.println("Enter the values at "+i+" "+j);
				arr[i][j]=sc.nextInt();
			}
		}
		
		
	}

	public static void displayData(int[][] arr) {
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		
	}

	public static int[][] add(int[][] arr, int[][] arr1) {
		int[][] temp=new int[arr.length][arr1.length];
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				temp[i][j]=temp[i][j]+arr[i][j]+arr1[i][j];
			}
		}
		
		
		return temp;
	}

	public static int[][] transpose(int[][] arr) {
		int[][] temp=new int[arr.length][arr.length];
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				temp[i][j]=arr[j][i];
			}
		}
		
		
		return temp;
	}

	public static int findMaxValue(int[][] arr) {
		int temp=arr[0][0];
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(arr[i][j]>temp)
				{
					temp=arr[i][j];
				}
			}
		}
		
		return temp;
	}

	public static int findMinValue(int[][] arr) {
		int temp=arr[0][0];
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(arr[i][j]<temp)
				{
					temp=arr[i][j];
				}
			}
		}
		
		return temp;
	}

	public static int findFrequency(int[][] arr, int val) {
	
		int cnt=0;
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(arr[i][j]==val)
				{
					cnt++;
				}
			}
		}
		
		return cnt;
	}

}
