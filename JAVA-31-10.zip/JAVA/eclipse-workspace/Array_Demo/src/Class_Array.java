import java.util.*;
public class Class_Array {

	public static void main(String[] args) {
	int x = 12;
	int arr[] = new int[5];
	ArrayService.acceptData(arr);
	ArrayService.displayData(arr);
	
	int sum = ArrayService.findSum(arr);
	int val = 5;
	int arr1[] = ArrayService.findAllGreaterVal(arr,val);
	System.out.println("Sum of all elements in given array : "+sum);
	System.out.println("Elements greater than "+val+" are : ");
	ArrayService.displayData(arr1);
	val = 10;
	int pos = ArrayService.searchValue(arr,val);
	if(pos!=-1)
	{
		System.out.println("found at "+pos);
	}
	else {
		System.out.println("not found");
	}
	
	
	}
}
