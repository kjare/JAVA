import java.util.*;
public class TestEmpArr {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int choice=0;
		do {
			System.out.println("\n1.Add new employee \n2.Modify Salary \n3.Display All");
			System.out.print("4.Display by id \n5.Calculate Salary by Id\n6.Calculate Bonus \n7.EXIT\n");
			choice=sc.nextInt();
			switch(choice)
			{	
				case 1:
					System.out.println("\n1.Salaried Emp \n2.Contract Emp \n3.Vendors");
					int ch=sc.nextInt();
					EmployeeService.addNewEmployee(ch);
					break;
					
				case 2:
					System.out.println("Enter ID");
					int pid=sc.nextInt();
					System.out.println("Enter Salary");
					double s=sc.nextDouble();
					boolean status=EmployeeService.ModifysalById(pid,s);
					if(status)
						System.out.println("Success");
					else 
						System.out.println("Id not found");
						break;
				case 3:
					EmployeeService.displayAll();
					break;
				case 4:
					System.out.println("Enter ID");
					pid=sc.nextInt();
					EmployeeService.displayById(pid);
//					status=EmployeeService.displayById(pid);
//					if(status)
//						System.out.println("Success");
//					else 
//						System.out.println("Id not found");
					break;
				case 5:
					System.out.println("Enter id");
					pid=sc.nextInt();
					double salary = EmployeeService.calculateSalaryById(pid);
					if(salary != -1)
					{
						System.out.println("Net Salary : "+salary);
						
					}
					else {
						System.out.println("not found");
					}
					break;
				case 6:
					System.out.println("Enter id");
					pid=sc.nextInt();
					double bonus = EmployeeService.calculateBonus(pid);
					if(bonus != -1)
					{
						System.out.println("\nBonus : "+bonus);
						
					}
					else {
						System.out.println("\nnot found");
					}
					break;
				case 7:
					break;
				default:
					System.out.println("WRONG CHOICE");
					break;
					
			}
			
			
			
		}while(choice!=7);
		
	}

}
