import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class EmployeeService {
	static Employee[] emparr;
	static int cnt;
	
	static{
		emparr = new Employee[100];
		emparr[0] = new SalariedEmp(10,"Kiran","111","k@gmail.com","HR","Development",LocalDate.of(2000,12,10),4000,400);
		emparr[1] = new SalariedEmp(20,"vidya","222","v@gmail.com","mgr","analyst",LocalDate.of(2001,11,11),4500,450);
		emparr[2] = new ContractEmp(30,"vishal","333","v@gmail.com","IT","Development",LocalDate.of(2002,10,10),45,450);
		emparr[3] = new ContractEmp(40,"bali","444","b@gmail.com","mgr","finance",LocalDate.of(2001,9,9),35,450);
		cnt = 4;
	}
	public static void addNewEmployee(int ch)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter ID : ");
		int pid = sc.nextInt();
		System.out.println("Enter name : ");
		String pname = sc.next();
		System.out.println("Enter mobile : ");
		String mobile = sc.next();
		System.out.println("Enter email : ");
		String email = sc.next();
		System.out.println("Enter dept : ");
		String dept = sc.next();
		System.out.println("Enter desg : ");
		String desg = sc.next();
		System.out.println("Enter DOJ : ");
		String dt=sc.next();
		LocalDate ldt=LocalDate.parse(dt,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		
		switch(ch)
		{
		case 1:
			System.out.println("Enter Salary");
			double s=sc.nextDouble();
			System.out.println("Enter Bonus");
			double b=sc.nextDouble();
			
			emparr[cnt]=new SalariedEmp(pid,pname,mobile,email,dept,desg,ldt,s,b);
			cnt++;
			break;
			
		case 2:
			System.out.println("Enter hrs");
			int hrs=sc.nextInt();
			System.out.println("Enter charges");
			double charges=sc.nextDouble();
			emparr[cnt]=new ContractEmp(pid, pname, mobile, email, dept, desg, ldt, hrs, charges);
			cnt++;
			break;
		case 3:
			System.out.println("Number of employees");
			int noOfEmp=sc.nextInt();
			System.out.println("Enter the amount");
			double amt=sc.nextDouble();
			emparr[cnt]=new Vendors(pid, pname, mobile, email, dept, desg, ldt, noOfEmp, amt);
			cnt++;
			break;
			
		
		}
		//cnt++;

	}
	
	public static void displayById(int pid)
	{
		int pos = searchById(pid);
		if(pos!=-1)
		{
			for(int i=0;i<cnt;i++)
			{
				if(emparr[i].getPid()==pid)
				{
					System.out.println(emparr[i]);
				}
			}
		}
		else
		{
			System.out.println("ID NOT FOUND");
		}
			
	}
	
	public static void displayAll()
	{
		for(Employee e:emparr)
		{
			if(e!=null)
			{
				System.out.println(e);
			}
			else
				break;
		}
	}


	public static boolean ModifysalById(int pid, double s) {
		
		int pos=searchById(pid);
		if(pos!=-1)
		{
			if(emparr[pos] instanceof SalariedEmp) 
			{
				((SalariedEmp)emparr[pos]).setSal(s);
			}
			else if(emparr[pos] instanceof ContractEmp)
			{
				((ContractEmp)emparr[pos]).setCharges(s);
				
			}
			else 
			{
				((Vendors)emparr[pos]).setAmount(s);
			}
			return true;
		}
		else 
			return false;
	}


	private static int searchById(int pid) {
		
		for(int i=0;i<cnt;i++)
		{
			if(emparr[i].getPid()==pid)
			{
				return i;
			}
		}
		
		return -1;
	}
	
	public static double calculateSalaryById(int pid)
	{
		int pos = searchById(pid);
		if(pos!=-1)
		{
			return emparr[pos].calculateSal();
		}
		return -1;
	}

//	public static double calculateBonus(int pid) {
//		int pos = searchById(pid);
//		if(pos!=-1)
//		{
//			return ((SalariedEmp) emparr[pos]).calculateBonus();
//		}
//		return -1;
//	}
	public static double calculateBonus(int pid) {
		int pos=searchById(pid);
		if(pos!=-1)
		{
			if(emparr[pos] instanceof SalariedEmp) 
			{
				return ((SalariedEmp)emparr[pos]).calculateBonus();
			}			
		}
		return -1;
	
}
}