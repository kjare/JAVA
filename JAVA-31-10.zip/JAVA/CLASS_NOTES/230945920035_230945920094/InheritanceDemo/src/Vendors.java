import java.time.LocalDate;

public class Vendors extends Employee 
{
	private int noOfEmployees;
	private double amount;
	public Vendors() {
		super();
	}
	public Vendors(int pid, String pname, String mobile, String email, String dept, String desg, LocalDate doj, int noOfEmployees, double amount) {
		super(pid, pname, mobile, email, dept, desg, doj);
		this.noOfEmployees=noOfEmployees;
		this.amount=amount;
		
		
	}
	public int getNoOfEmployees() {
		return noOfEmployees;
	}
	public void setNoOfEmployees(int noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return super.toString() +"Vendors [noOfEmployees=" + noOfEmployees + ", amount=" + amount + "]";
	}
	
}
