
public class Members extends Person{

	private String typeOfMembership;
	private double amount;

	public Members() {
		super();
		
	}


	public Members(int pid, String pname, String mobile, String email,String typeOfMembership, double amount) {
		super(pid, pname, mobile, email);
		this.typeOfMembership = typeOfMembership;
		this.amount = amount;
	}


	public String getTypeOfMembership() {
		return typeOfMembership;
	}


	public void setTypeOfMembership(String typeOfMembership) {
		this.typeOfMembership = typeOfMembership;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	@Override
	public String toString() {
		return super.toString()+"Members [typeOfMembership=" + typeOfMembership + ", amount=" + amount + "]";
	}	
	
	
	
	
}



	
	
	

