import java.time.LocalDate;

public class TestEmployee {

	public static void main(String[] args) {
		
		//public Employee(int pid, String pname, String mobile, String email,String dept, String desg, LocalDate doj) {
		
//		Person p=new Person(12,"xxx","3333","asd@gmail.com");
//		System.out.println(p);
		
//		Vendors v=new Vendors(13,"Rajat","4444","a@gmail.com","hr","associate",LocalDate.of(2002, 12,30),30,4000);
//		System.out.println(v);
	
//		Members m=new Members(13,"Rajat","4444","a@gmail.com","Annual",4000);
//		System.out.println(m);
		
		Employee e=new Employee(12,"xxx","3333","asd@gmail.com","Hr","mgr",LocalDate.of(2001,11,23));
      System.out.println(e);		
		SalariedEmp semp=new SalariedEmp(12,"Rajat","4444","a@gmail.com","hr","associate",LocalDate.of(2002, 12,30),4556,345);
		System.out.println(semp);	
		System.out.println(semp.getBonus());
		
		ContractEmployee cemp=new ContractEmployee(13,"Rajat","4444","a@gmail.com","hr","associate",LocalDate.of(2002, 12,30),30,4000);
		System.out.println(cemp);
		
		Employee e2 = new SalariedEmp(12,"Rajat","4444","a@gmail.com","hr","associate",LocalDate.of(2002, 12,30),4556,345);
		System.out.println(((SalariedEmp)e2).getBonus());

		
		Employee e1 =  new SalariedEmp(12,"Rajat","4444","a@gmail.com","hr","associate",LocalDate.of(2002, 12,30),4556,345);
		double k=((SalariedEmp)e1).getBonus();
		System.out.println("bonus : "+k);
		System.out.println(((SalariedEmp)e1).getBonus());
		
//		Person p=new SalariedEmp();
//		System.out.println(p);
//		SalariedEmp s=(SalariedEmp)e1;
//		System.out.println(s.getSal());
//		e1.getSal();
		
		
		
	}

}
