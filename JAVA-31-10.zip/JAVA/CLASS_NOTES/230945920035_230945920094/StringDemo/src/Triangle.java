import java.util.*;
public class Triangle 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of rows to be printed : ");
		int rows = sc.nextInt();
		// to print given number of rows
		for(int i=1; i<=rows; i++)
		{
			// to print no of spaces
			for(int j=rows; j>=i; j--)
			{
				System.out.println(" ");
			}
			// to print no of stars
			for(int j=1; j<=i; j++)
			{
				System.out.println("* ");
			}
			// for new line
			//System.out.println();
		
		}
		sc.close();
	}
	
}
