
public class StringDemo2 {
	public static void main(String[] args) {
		String s="TestString";
		System.out.println("uppercase --> "+s.toUpperCase());
		System.out.println("lowercase --> "+s.toLowerCase());
	
		System.out.println("charAt  "+s.charAt(5));
		System.out.println("length  "+s.length());
		String t1="ABC PQR,XYZ";
		System.out.println(t1);
		String sarr[]=t1.split(" ");
		System.out.println(sarr[1]);
		System.out.println(sarr.length);
		System.out.println(s.substring(3,6));
		System.out.println(s.substring(3));
		System.out.println(s.indexOf("s"));
		System.out.println(s.lastIndexOf("S"));
		StringBuilder sb=new StringBuilder("String builder  ");
		sb.append("test append");
		System.out.println(sb);
	}

}
