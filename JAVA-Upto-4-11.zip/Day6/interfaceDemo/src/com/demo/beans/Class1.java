package com.demo.beans;

import com.demo.interfaces.Interface31;

public class Class1 implements Interface31{

	@Override
	public void display() {
		System.out.println("in display method");
		
	}

}
