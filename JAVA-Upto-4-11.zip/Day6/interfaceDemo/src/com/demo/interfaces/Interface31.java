package com.demo.interfaces;

public interface Interface31 {
  void display();
}
