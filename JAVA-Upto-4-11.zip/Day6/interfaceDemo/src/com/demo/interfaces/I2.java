package com.demo.interfaces;

public interface I2 {
	void funct21();
	int funct22();
}
