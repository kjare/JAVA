package com.demo.exceptions;

public class BlockedAccountException extends Exception{
	public BlockedAccountException(String msg) {
		super(msg);
		
	}

}
