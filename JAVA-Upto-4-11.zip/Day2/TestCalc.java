class TestCalc
{
	public static void table(int n)
	{
	int ans=1,t=1;
	while(t<=10)
	{
		System.out.println(n+"*"+t+"="+n*t);
		t++;
	}
	}


		public static void CheckPrime(int num){
		int i=2;
		while(i<num)
		{
			if(num%2==0)
			{
				break;
			}
			i++;
		}
		if(i==num)
		{
			System.out.println("prime");
		}
		else{
			System.out.println("not prime");
		}
		}

		
	public static void Pattern(int rows){	
			
	for (int m=1; m<=rows; m++)
	{
	for (int n=rows; n>m; n--)
	{
	System.out.print(" ");
	}
	for (int p=1; p<=(m * 2) -1; p++)
	{
	System.out.print("*");
	}
	System.out.println();
	}
	for (int m=rows-1; m>=1; m--)
	{
	for (int n=rows-1; n>=m; n--)
	{
	System.out.print(" ");
	}
	for (int p=1; p<=(m * 2) -1; p++)
	{
	System.out.print("*");
	}
	System.out.println();
	}
	}


}