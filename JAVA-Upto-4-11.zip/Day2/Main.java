import java.util.*;

class Main
{
	public static void main(String[] args)
	{
		
		int choice;
	
			
		System.out.println("Enter your choice : \n1.Print Table \n2.Prime Number \n3.Display Pattern");
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		switch (choice) {
		case 1:
		System.out.println("Enter the number");
		
		int n=sc.nextInt();
		TestCalc.table(n);
		break;
		
		case 2:
		System.out.println("\nEnter the number to check whether its prime or not");		
		int j=sc.nextInt();
		TestCalc.CheckPrime(j);
		break;
		
		case 3:
		System.out.println("Enter the odd number of rows  ");
		int k = sc.nextInt();
		TestCalc.Pattern(k);
		break;
		}
		
	

}
}