
public class TestStudent {

	public static void main(String[] args) {
		Student s1=new Student("Sejal",78,97,78);
		System.out.println(s1);
		Student s2=new Student("Atharva",88,98,78);
		System.out.println(s2);
		Student s3=new Student();
		System.out.println(s3);
	}

}
