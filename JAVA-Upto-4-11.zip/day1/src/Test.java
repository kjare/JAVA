class Test{
  public static void main(String[] args){
      byte b=2;
	  short s=b;      //implicit typecasting
	  byte x=s; //explicit typecasting
	  long l=34;
	  float f=l;
  }
}